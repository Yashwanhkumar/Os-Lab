# 15b program file
[program file](program1.png)

# 15b sample output
[sample output](sampleoutput.png)

# 15b tested output
[tested output](testedoutput.png)
