# 17a program file
[program file](program.jpg)

# 17a sample output
[sample output](sampleoutput.jpg)

# 17a tested output
[tested output](testedoutput.jpg)
