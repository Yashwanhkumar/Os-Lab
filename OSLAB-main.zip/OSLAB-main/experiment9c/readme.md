# 9c Program file
[program file](program.png.jpg)

# 9c Sample output
[sample output](sampleoutput.png.jpg)

# 9c Tested output
[tested output](testedoutput.png.jpg)
