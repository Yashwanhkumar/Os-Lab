# 14a program file
[program file](program.jpg)

# 14a sample output
[sample output](sampleoutput.jpg)

# 14a tested output
[tested output](testedoutput.jpg)
