# 12b program file
[program file](program.jpg)

# 12b sample output
[sample output](sampleoutput.jpg)

# 12b tested output
[tested output](testedoutput.jpg)
