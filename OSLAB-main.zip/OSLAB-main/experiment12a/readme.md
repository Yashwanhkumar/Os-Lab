# 12a program file
[program file](program.jpg)

# 12a sample output
[sample output](sampleoutput.jpg)

# 12a tested output
[tested output](testedoutput.jpg)
