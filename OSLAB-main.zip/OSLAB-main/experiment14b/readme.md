# 14b program file
[program file](program.jpg)

# 14b sample output
[sample output](sampleoutput.jpg)

# 14b tested output
[tested output](testedoutput.jpg)
