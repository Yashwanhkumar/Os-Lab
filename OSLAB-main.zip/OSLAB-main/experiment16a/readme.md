# 16a program file
[program file](program.png)

# 16a sample output
[sample output](sampleoutput.png)

# 16a tested output
[tested output](testedoutput.png)
