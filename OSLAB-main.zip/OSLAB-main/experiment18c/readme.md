# 18c program file
[program file](program.png)

# 18c sample output
[sample output](sampleoutput.png)

# 18c tested output
[tested output](testedoutput.png)
