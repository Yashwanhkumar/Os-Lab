# 9b program file
[program file](SJF_C.txt)

# 9b sample output
[sample output](pogramoutput.png)

# 9b tested output
[tested output](testedoutput.png)
