# 9a program file
[program file](FCFS_C.txt)

# 9a sample output
[sample output](programoutput.png)

# 9a tested output
[tested output](testedoutput.png)
